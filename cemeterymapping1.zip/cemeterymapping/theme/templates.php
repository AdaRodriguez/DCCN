<?php
require_once(LIB_PATH.DS."config.php");

class Database {
    private $conn;

    function __construct() {
        $this->open_connection();
    }

    public function open_connection() {
        $this->conn = mysqli_connect(server, user, pass, database_name);

        if (!$this->conn) {
            echo "Problem in database connection! Contact administrator!";
            exit();
        }
    }

    function setQuery($sql='') {
        $this->sql_string = $sql;
    }

    function executeQuery() {
        $result = mysqli_query($this->conn, $this->sql_string);
        $this->confirm_query($result);
        return $result;
    }

    private function confirm_query($result) {
        if (!$result) {
            $this->error_no = mysqli_errno($this->conn);
            $this->error_msg = mysqli_error($this->conn);
            return false;
        }
        return $result;
    }

    function loadResultList($key='') {
        $cur = $this->executeQuery();
        $array = array();

        while ($row = mysqli_fetch_object($cur)) {
            if ($key) {
                $array[$row->$key] = $row;
            } else {
                $array[] = $row;
            }
        }

        mysqli_free_result($cur);
        return $array;
    }

    function loadSingleResult() {
        $cur = $this->executeQuery();
        $row = mysqli_fetch_object($cur);
        mysqli_free_result($cur);
        return $row;
    }

    function getFieldsOnOneTable($tbl_name) {
        $this->setQuery("DESC ".$tbl_name);
        $rows = $this->loadResultList();
        $f = array();

        for ($x=0; $x<count($rows); $x++) {
            $f[] = $rows[$x]->Field;
        }

        return $f;
    }

    public function fetch_array($result) {
        return mysqli_fetch_array($result);
    }

    public function num_rows($result_set) {
        return mysqli_num_rows($result_set);
    }

    public function insert_id() {
        return mysqli_insert_id($this->conn);
    }

    public function affected_rows() {
        return mysqli_affected_rows($this->conn);
    }

    public function escape_value($value) {
        return mysqli_real_escape_string($this->conn, $value);
    }

    public function close_connection() {
        if (isset($this->conn)) {
            mysqli_close($this->conn);
            unset($this->conn);
        }
    }
}

$mydb = new Database();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title><?php echo $title; ?> | Cemetery Mapping and Information System</title>

<!-- Bootstrap Core CSS -->
<link href="<?php echo web_root; ?>css/bootstrap.min.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo web_root; ?>font/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo web_root; ?>font/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- DataTables CSS -->
<link href="<?php echo web_root; ?>css/dataTables.bootstrap.css" rel="stylesheet">

<!-- datetime picker CSS -->
<link href="<?php echo web_root; ?>css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

<link href="<?php echo web_root; ?>css/ekko-lightbox.css" rel="stylesheet">
<link href="<?php echo web_root; ?>css/modern.css" rel="stylesheet">
<link href="<?php echo web_root; ?>css/costum.css" rel="stylesheet">
<link rel="icon" href="<?php echo web_root; ?>img/favicon.ico" type="image/x-icon">

<style type="text/css">

.p {
  color: white;
  margin-bottom: 0;
  margin-top: 0;
  list-style: none;
}

.p > a { 
  color: white;
  margin-bottom: 0;
  margin: 0;
  padding: 0;
  text-decoration:none;
  background-color:  #0000FF;
}

.p > a:hover,
.p > a:focus {
  color: black; 
  text-decoration:none;
  background-color: #2d52f2;
}

.title-logo  {
    color:black;
    text-decoration:none;
    font-size: 50px;
    font-family: "broadway";
    padding: 0;
    margin: 0;
    top: 0;
}

.title-logo:hover {
  color: blue; 
  text-decoration:none; 
}

.carttxtactive {
  color: red;
  font-style: bold;
  box-shadow: red;
}

.carttxtactive:hover {
  color: white;
}

</style>

<?php
if (isset($_SESSION['gcCart'])){
  if (count($_SESSION['gcCart']) > 0) {
    $cart = '<label class="label label-danger">'.count($_SESSION['gcCart']) .'</label>';
  } 
} 
?>

<script type="text/javascript">

</script>
</head>

<body style="background-color:#e0e4e5" onload="totalprice()">

<div class="navbar-fixed-top navbar-inverse" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <h5 class="navbar-menu p">Cemetery Mapping and Information System</h5>
      <button type="button" class="navbar-toggle btn-xs p" data-toggle="collapse" data-target=".smMenu">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button> 
    </div>
    <div  class="collapse navbar-collapse smMenu "> 

      <ul class="navbar-nav p navbar-left tooltip-demo" style="margin-left:-8%;"> 
          <li class="dropdown dropdown-toggle ">
            <a  data-toggle="tooltip" data-placement="bottom" title="Cemetery Mapping and Information System"   href="#"> 
             <i class="fa fa-info fa-fw"> </i>   
            </a>
          </li> 
      </ul>

    </div>

  </div>
</div>

<div class=" " style=" margin-top:-2%"> 
  <!-- <div class="col-md-10 col-md-offset-1 " >  -->
    <div class="col-md-12" style="margin-bottom: 9px;">
      <div class="row">
        <?php require_once 'banner.php'; ?>
      </div>  
    </div>
</div>

<div class="navbar navbar-static-top navbar-inverse" role="navigation">
  <div class="container ">
    <div class="navbar-header"> 
        <div class="navbar-menu p" >Menu</div>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".bigMenu">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button> 
    </div>

    <div class="collapse navbar-collapse bigMenu" style="float:left"> 
      <ul class="nav navbar-nav" > 
        <li class="dropdown dropdown-toggle <?php echo (isset($_GET['q']) && $_GET['q'] == '') ? "active" : false;?> ">      
          <li class="dropdown-toggle <?php echo (isset($_GET['q']) && $_GET['q'] == 'about') ? "active" : false;?>">        
            <a href="<?php echo web_root.'index.php'; ?>"> Home</a>
          </li>
          <li class="dropdown-toggle <?php echo (isset($_GET['q']) && $_GET['q'] == 'contact') ? "active" : false;?>">
            <a href="<?php echo web_root.'index.php?q=person'; ?>"> Deceased Person</a>
          </li>
          <li class="dropdown-toggle <?php echo (isset($_GET['q']) && $_GET['q'] == 'about') ? "active" : false;?>">
            <a href="<?php echo web_root.'index.php?q=contact';  ?>"> Contact Us</a>
          </li>
          <li class="dropdown-toggle <?php echo (isset($_GET['q']) && $_GET['q'] == 'service') ? "active" : false;?>">
            <a href="<?php echo web_root.'index.php?q=about';  ?>"> About Us</a>
          </li>
      </ul>           
    </div>
  </div>
</div> 

<div class="container"> 
   <!-- start content --> 
  <div class="row"> 
    <div id="page-wrapper">
      <?php

      if($title=='Profile' or $title=='Track Order'){
        echo ' <div class="row">';
        require_once $content;
        echo ' </div><br/>';
      } else {
        // check_message(); ?>

        <?php
        if (isset($_GET['category'])) {
          $categid = isset($_GET['category']) ? $_GET['category'] : ''; 
          $sql="SELECT * FROM `tbltype` WHERE `TYPEID`=".$categid;
          $mydb->setQuery($sql);
          $cur = $mydb->loadSingleResult();
        }
        ?>

        <?php if (!isset($_GET['graveno'])): ?>
          <div class="row">
            <div class="col-lg-3"> 
              <?php require_once "leftbar.php"; ?>
            </div>
            <div class="col-lg-6">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <b><?php echo $title . (isset($cur->TYPES) ?  '  |  ' .$cur->TYPES : '' )?></b> 
                </div>
                <div class="panel-body"> 
                  <?php require_once $content; ?> 
                </div>
              </div>
            </div> 
            <div class="col-lg-3"> 
              <?php require_once "sidebar.php"; ?>
            </div>
          </div>
        <?php endif ?>

        <?php if (isset($_GET['graveno'])): ?>
          <div class="row">
            <div class="col-lg-12">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <b>Map Section | <a  href="#" class="findgrave" style="color: red"><?php echo (isset($_GET['name']) ?  $_GET['name'] : '' )?></a></b> 
                </div>
                <div class="panel-body"> 
                  <?php require_once "map.php"; ?>
                </div>
              </div>
            </div>
          </div>
        <?php endif ?>

      <?php } ?>

    </div>        
  </div>
</div>

<footer class="panel-footer" style="background-color:#000;color:white" >
  <p align="left" >&copy; Cemetery Mapping and Information System</p>
</footer>

<!-- modalorder -->
<div class="modal fade" id="myOrdered">
</div>
<!-- end -->

<!-- jQuery -->
<script src="<?php echo web_root; ?>jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo web_root; ?>js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript --> 
<!-- DataTables JavaScript -->
<script src="<?php echo web_root; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo web_root; ?>js/dataTables.bootstrap.min.js"></script>


<script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/ekko-lightbox.js"></script> 
<script type="text/javascript" src="<?php echo web_root; ?>js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo web_root; ?>js/locales/bootstrap-datetimepicker.uk.js" charset="UTF-8"></script>

<script src="<?php echo web_root; ?>angularjs/angular.min.js"></script>
<script src="<?php echo web_root; ?>angularjs/angular-animate.min.js"></script>
<script src="<?php echo web_root; ?>angularjs/angular-aria.min.js"></script>
<script src="<?php echo web_root; ?>angularjs/angular-messages.min.js"></script>

<!-- Custom Theme JavaScript --> 
<script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/janobe.js"></script>  

<script>
$(function() {
  $("[autofocus]").on("focus", function() {
    if (this.setSelectionRange) {
      var len = this.value.length * 2;
      this.setSelectionRange(len, len);
    } else {
      this.value = this.value;
    }
    this.scrollTop = 999999;
  }).focus();
});

var currentZoom = 1.0;

$(document).ready(function () {
  $('#zoom').animate({ 'zoom': currentZoom}, 'slow');

  $('#btn_ZoomIn').click(
    function () {
      $('#zoom').animate({ 'zoom': currentZoom += .1 }, 'slow');
    })
  $('#btn_ZoomOut').click(
    function () {
      $('#zoom').animate({ 'zoom': currentZoom -= .1 }, 'slow');
    })
  $('#btn_ZoomReset').click(
    function () {
      currentZoom = 1.0
      $('#zoom').animate({ 'zoom': 1 }, 'slow');
    })
});
</script>

<script type="text/javascript">
angular.module('gridListDemo1', ['ngMaterial'])
.controller('AppCtrl', function($scope) {});

$(document).on("click", ".proid", function () {
  var prd_id = $(this).data('id')
  var prd_name = $(this).data('name')
  var prd_price = $(this).data('price')
  var prd_image = $(this).data('image')
  var prd_category = $(this).data('category')
  var prd_available = $(this).data('available')
  var prd_discount = $(this).data('discount')
  var prd_tax = $(this).data('tax')

  $(".modal-body #prod_id").val( prd_id );
  $(".modal-body #prod_name").text(prd_name );
  $(".modal-body #prod_price").val(prd_price );
  $(".modal-body #prod_image").attr("src", prd_image );
  $(".modal-body #prod_category").text(prd_category );
  $(".modal-body #prod_available").text(prd_available );
  $(".modal-body #prod_discount").text(prd_discount );
  $(".modal-body #prod_tax").text(prd_tax );
  $(".modal-body #QTY").attr("value", "1" );
  $("#QTY").val(1)
  $('.item_quantity').val('1');
  $('#cartForm').show();
  $('#report').hide();
  $('#cart').hide(); 
  $('#product').hide();
  $('#qty').show(); 
  $('#check').show();
  $('#process').hide();

  $('#base').hide();
  $('#categ').show();
});

$(document).on("click", ".findgrave", function () {
  $('#myOrdered').empty();
  var name = $(this).text();
  var categ_id = <?php echo $_GET['category']; ?>;

  $.ajax({    //create an ajax request to display.php
    type: "GET",
    url: "findgrave.php?name="+name+"&category="+categ_id,             
    dataType: "html",   //expect html to be returned                
    success: function(response){                    
      $("#myOrdered").html(response); 
      //alert(response);
    }
  });
});

</script>
</body>
</html>
