<!-- first layer -->
<table>
	<tr>
		<td>
		    <div style="margin:0px 0px 0px 0px;" class="row">
				<?php   
				$gravenofrom=13;
				$gravenoto=14;
				$height =40;
				$width =20;
				retrieveData_DESC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>
			<div style="margin:0px 0px 0px 0px;" class="row">
				<?php   
				$gravenofrom=10;
				$gravenoto=12;
				$height =20;
				$width =40;
				retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>
		</td>
		<td>
		    <div style="margin:20px 0px 0px 0px;padding: 0px 0px 0px 0px;" class="col-xs-6">
				<?php   
				$gravenofrom=15;
				$gravenoto=16;
				$height =40;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div> 
			<div style="margin:0px 0px 0px 0px;padding: 0px 6px 0px 0px;" class="col-xs-6">
				<?php   
				$gravenofrom=17;
				$gravenoto=18;
				$height =30;
				$width =20;
				retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div> 
		</td>
		<td>
		    <div style="margin:20px 0px 0px 0px;padding: 0px 0px 0px 0px;" class="">
				<?php   
				$gravenofrom=19;
				$gravenoto=24;
				$height =40;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>  
		</td>
		<td>
			<div style="margin:0px 0px 5px 0px;padding: 0px 0px 0px 0px;" class="">
				<?php   
				$gravenofrom=28;
				$gravenoto=28;
				$height =30;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>  
		    <div style="margin:20px 0px -20px 0px;padding: 0px 0px 0px 0px;" class="">
				<?php   
				$gravenofrom=25;
				$gravenoto=26;
				$height =30;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div> 
			<div style="margin:20px 0px -20px 5px;padding: 0px 0px 0px 0px;" class="">
				<?php   
				$gravenofrom=27;
				$gravenoto=27;
				$height =30;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>  
		</td>
		<td>
			<div class="row">
				 <div style="margin:0px 0px 0px 30px;padding: 0px 0px 0px 0px;" class="col-xs-8">
					<?php   
					$gravenofrom=163;
					$gravenoto=171;
					$height =30;
					$width =15;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div> 
				<div style="margin:-30px 0px 0px 150px;padding: 0px 0px 0px 0px;" class="col-xs-1">
					<?php   
					$gravenofrom=172;
					$gravenoto=173;
					$height =15;
					$width =15;
					retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div> 
				<div style="margin:-30px 0px 0px -14px;padding: 0px 0px 0px 0px;" class="col-xs-3">
					<?php   
					$gravenofrom=174;
					$gravenoto=176;
					$height =30;
					$width =15;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>
			</div>
		   <div class="row"> 
			    <div style="margin:10px 0px 0px 30px;padding: 0px 0px 0px 0px;" class="col-xs-6">
					<?php   
					$gravenofrom=29;
					$gravenoto=30;
					$height =30;
					$width =15;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div> 
				<div style="margin:-30px 0px 0px 70px;padding: 0px 0px 0px 0px;" class="col-xs-5">
					<?php   
					$gravenofrom=31;
					$gravenoto=37;
					$height =30;
					$width =15;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div> 
					<div style="margin:-30px 0px 0px -20px;padding: 0px 0px 0px 0px;" class="col-xs-1">
					<?php   
					$gravenofrom=38;
					$gravenoto=39;
					$height =15;
					$width =15;
					retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>
			 </div>
		</td>
		<td>
			<div class="row">
				 <div style="margin:0px 0px 0px -80px;padding: 0px 0px 0px 0px;" class="col-xs-12">
					<?php   
					$gravenofrom=177;
					$gravenoto=177;
					$height =40;
					$width =40;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>  
			</div>
			<div style="margin:0px 0px 0px -110px;padding: 0px 0px 0px 0px;" class="col-xs-6">
				<?php   
				$gravenofrom=40;
				$gravenoto=43;
				$height =30;
				$width =15;
				retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>  
			<div style="margin:0px 0px 0px -70px;padding: 0px 0px 0px 0px;" class="col-xs-5">
				<?php   
				$gravenofrom=44;
				$gravenoto=45;
				$height =15;
				$width =15;
				retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div> 
			<div style="margin:0px 0px 0px  -60px;padding: 0px 0px 0px 0px;" class="col-xs-1">
				<?php   
				$gravenofrom=46;
				$gravenoto=46;
				$height =30;
				$width =15;
				retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width) ;?> 
			</div>  
			  
		</td> 
		<td>
			<div class="row">
				 <div style="margin:0px 0px 5px -30px;padding: 0px 0px 0px 0px;" class="col-xs-12">
					<?php   
					$gravenofrom=392;
					$gravenoto=401;
					$height =30;
					$width =10;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>  
			</div> 

			<div class="row">
				 <div style="margin:0px 0px 0px 0px;padding: 0px 0px 0px 0px;" class="col-xs-12">
					<?php   
					$gravenofrom=47;
					$gravenoto=51;
					$height =30;
					$width =10;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>  
			</div> 
		</td> 
		<td>
			<div class="row">
				 <div style="margin:40px 0px 0px 20px;padding: 0px 0px 0px 0px;" class="col-xs-12">
					<?php   
					$gravenofrom=52;
					$gravenoto=56;
					$height =30;
					$width =30;
					retrieveData_ASC_Horizontal_D($gravenofrom,$gravenoto,$height,$width) ;?> 
				</div>  
			</div> 
 
		</td> 
	</tr>

 
</table>