<?php 
require_once("../include/initialize.php");

// Check if user is logged in
if (!isset($_SESSION['USERID'])){
    redirect(web_root."admin/login.php");
}

$content='home.php';
$view = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
switch ($view) {
    case '1' :
        $title="Administrator Panel";  
        $content='home.php';      
        break;  
    default :
        $title="Administrator Panel";  
        $content ='home.php';      
}

// Attempt to include the templates.php file
$template_file = "theme/templates.php";
if (file_exists($template_file)) {
    require_once($template_file);
} else {
    // If the file doesn't exist, display an error message
    echo "Error: The templates file does not exist.";
}
?>
