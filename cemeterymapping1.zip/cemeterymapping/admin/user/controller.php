<?php
require_once("../../include/accounts.php");

$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add':
		doInsert();
		break;
	
	case 'edit':
		doEdit();
		break;
	
	case 'delete':
		doDelete();
		break;

	case 'photos':
		doupdateimage();
		break;
}

function doInsert() {
	if (isset($_POST['save'])) {
		if ($_POST['U_NAME'] == "" || $_POST['U_USERNAME'] == "" || $_POST['U_PASS'] == "") {
			message("All fields are required!", "error");
			redirect('index.php?view=add');
		} else {	
			$user = new User();
			$user->U_NAME = $_POST['U_NAME'];
			$user->U_USERNAME = $_POST['U_USERNAME'];
			$user->U_PASS = sha1($_POST['U_PASS']);
			$user->U_ROLE = $_POST['U_ROLE'];
			$user->create();

			message("New user [" . $_POST['U_NAME'] . "] created successfully!", "success");
			redirect("index.php");
		}
	}
}

function doEdit() {
	if (isset($_POST['save'])) {
		$user = new User(); 
		$user->U_NAME = $_POST['U_NAME'];
		$user->U_USERNAME = $_POST['U_USERNAME'];
		$user->U_PASS = sha1($_POST['U_PASS']);
		$user->U_ROLE = $_POST['U_ROLE'];
		$user->update($_POST['USERID']);

		message("User [" . $_POST['U_NAME'] . "] has been updated!", "success");
		redirect("index.php");
	}
}

function doDelete() {
	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$user = new User();
		$user->delete($id);
			 
		message("User already deleted!", "info");
		redirect('index.php');
	}
}

function doupdateimage() {
	if ($_FILES['photo']['error'] > 0) {
		message("No image selected!", "error");
		redirect("index.php?view=view&id=" . $_GET['id']);
	} else {
		$myfile = $_FILES['photo']['name'];
		$location = "photos/" . $myfile;
		move_uploaded_file($_FILES['photo']['tmp_name'], $location);

		$user = new User();
		$user->USERIMAGE = $location;
		$user->update($_SESSION['USERID']);
		redirect("index.php");
	}
}
?>
