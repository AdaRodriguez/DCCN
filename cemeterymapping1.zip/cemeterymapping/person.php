<?php 
$search = isset($_POST['search']) ? $_POST['search'] : "";
$location = isset($_GET['location']) ? $_GET['location'] : '';

// Assuming $mydb is already defined elsewhere in your code

?>

<style type="text/css">
    .scrollxy {
        width: auto;
        height:340px;
        overflow: auto; 
    }  
</style>

<div class="scrollxy">  
    <table id="" class="table">
        <thead>
            <tr>
                <th>Grave No</th>
                <th>Name of the Deceased</th>
                <th>Born</th>
                <th>Died</th>
                <th>Location</th>
                <th>Years Buried</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($_GET['location'])) {
                if (isset($_GET['name'])) {
                    $sql = "SELECT * FROM tblpeople WHERE LOCATION = ? AND GRAVENO = ? AND FNAME = ?";
                    $mydb->setQuery($sql, array($location, $_GET['graveno'], $_GET['name']));
                } else {
                    $sql = "SELECT * FROM tblpeople WHERE LOCATION = ?";
                    $mydb->setQuery($sql, array($location));
                }
            } elseif (!empty($search)) {
                $sql = "SELECT * FROM tblpeople WHERE FNAME LIKE ?";
                $mydb->setQuery($sql, array("%$search%"));
            } else {
                $sql = "SELECT * FROM tblpeople";
                $mydb->setQuery($sql);
            }

            $cur = $mydb->executeQuery();
            $numrows = $mydb->num_rows($cur);

            if ($numrows > 0) {
                $cur = $mydb->loadResultList();

                foreach ($cur as $res) {
                    $age = ''; // Initialize age variable

                    // Check if DIEDDATE is not empty before formatting
                    if (!empty($res->DIEDDATE)) {
                        // Attempt to create a DateTime object from DIEDDATE
                        $dateTime = date_create($res->DIEDDATE);
                        if ($dateTime !== false) {
                            // Formatting the date
                            $formatdate = date_format($dateTime, 'm/d/Y');
                            
                            // Calculate age
                            $birthDate = $formatdate;
                            $birthDate = explode("/", $birthDate);
                            $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md"))
                                ? ((date("Y") - $birthDate[2]) - 1)
                                : (date("Y") - $birthDate[2]);
                        } else {
                            // Date creation failed
                            echo '<tr><td colspan="6">Error: Failed to create date from DIEDDATE.</td></tr>';
                        }
                    }

                    echo '<tr>';
                    echo '<td>'.$res->GRAVENO.'</td>';
                    echo '<td><a href="index.php?q=person&graveno='.$res->GRAVENO.'&name='.$res->FNAME.'&location='.$res->LOCATION.'&section='.$res->CATEGORIES.'">'. $res->FNAME.'</a></td>';
                    echo '<td>'.$res->BORNDATE.'</td>';
                    echo '<td>'.$res->DIEDDATE.'</td>';
                    echo '<td>'.$res->LOCATION.'</td>';
                    echo '<td>'.$age.'</td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr>'; 
                echo '<td colspan="6" style="text-align:center">No Record Found!</td>'; 
                echo '</tr>'; 
            }
            ?>
        </tbody>
    </table>
</div>
