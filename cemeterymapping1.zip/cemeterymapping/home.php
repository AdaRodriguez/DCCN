<div>
	<img src="img/h3.jpg" class="col-md-4"><p class="col-md-8"><h3>Early history</h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Daet is a coastal municipality in the province of Camarines Norte. It serves as the provincial capital.

</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The municipality has a land area of 46.00 square kilometers or 17.76 square miles which constitutes 2.02% of Camarines Norte's total area. Its population as determined by the 2020 Census was 111,700. This represented 17.74% of the total population of Camarines Norte province, or 1.84% of the overall population of the Bicol Region. Based on these figures, the population density is computed at 2,428 inhabitants per square kilometer or 6,289 inhabitants per square mile.
</p>
</div>

<div>
	<img src="img/h1.jpg" class="col-md-4"><p class="col-md-8"><h3>Modern history</h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The name Daet is believed to be an ancient Bicolano term which means “to make friend” or “to be reconciled”.

</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Daet was the scene of violent protests against the Marcos dictatorship. On June 14, 1982, forces of the state opened fire on the rallyists who were mostly farmers demanding an increase in copra prices and to denounce abuses of the Marcos Regime.
</p>
</div>