 <table> 
	<tr>
		 
		<td>  
			<div style="margin: 0px 0px 20px 0px;">
				<?php  
				$gravenofrom =2;
				$gravenoto = 2;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
			<div style="margin: 0px 0px 0px 10px;">
				<?php  
				$gravenofrom =1;
				$gravenoto = 1;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td> 
		<td>     
			<div style="margin: 0px 0px 40px 10px;">
				<?php  
				$gravenofrom =3;
				$gravenoto = 3;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Horizontal_D($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td> 
		<td>     
			<div style="margin: 0px 0px 5px 10px;">
				<?php  
				$gravenofrom =4;
				$gravenoto = 5;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 10px;">
				<?php  
				$gravenofrom =6;
				$gravenoto = 6;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_D($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td> 
		<td>     
			<div style="margin: -20px 0px 5px 5px;">
				<?php  
				$gravenofrom =7;
				$gravenoto = 9;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 5px;">
				<?php  
				$gravenofrom =10;
				$gravenoto = 11;
				$height = 20;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td>
		<td>     
			<div style="margin: 0px 0px 5px 5px;">
				<?php  
				$gravenofrom =12;
				$gravenoto = 15;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 5px;">
				<?php  
				$gravenofrom =16;
				$gravenoto = 17;
				$height = 30;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td>   
		<td>     
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =20;
				$gravenoto = 25;
				$height = 13;
				$width = 20; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =18;
				$gravenoto = 19;
				$height = 30;
				$width = 15; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>   
		</td>  
		<td>     
			<div style="margin: 0px 0px 5px 10px;">
				<?php  
				$gravenofrom =26;
				$gravenoto = 31;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>     
		</td> 
		<td>     
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =43;
				$gravenoto = 44;
				$height = 10;
				$width = 25; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin:0px 0px 5px 0px;">
				<?php  
				$gravenofrom =34;
				$gravenoto = 38;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px -25px 0px;">
				<?php  
				$gravenofrom =32;
				$gravenoto = 33;
				$height = 30;
				$width = 20; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>     
		</td>
		<td>     
			<div style="margin: 0px 0px 12px -18px;">
				<?php  
				$gravenofrom =45;
				$gravenoto = 45;
				$height = 20;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =39;
				$gravenoto = 40;
				$height = 40;
				$width = 20; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =48;
				$gravenoto = 49;
				$height = 30;
				$width = 20; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>     
		</td> 
		<td>     
			<div style="margin: 0px 0px 25px 0px;">
				<?php  
				$gravenofrom =41;
				$gravenoto = 41;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =46;
				$gravenoto = 47;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: -5px 0px 5px 15px;">
				<?php  
				$gravenofrom =51;
				$gravenoto = 51;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
			</div>  
			<div style="margin: -5px 0px 5px 15px;">
				<?php  
				$gravenofrom =50;
				$gravenoto = 51;
				$height = 30;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?> 
			</div>       
		</td>   
		<td>     
			<div style="margin: -60px 0px 25px 0px;">
				<?php  
				$gravenofrom =42;
				$gravenoto = 42;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =52;
				$gravenoto = 54;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>  
		</td>  
		<td>     
			<div style="margin: 0px 0px 8px -30px;">
				<?php  
				$gravenofrom =57;
				$gravenoto = 59;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>  
			<div style="margin: 2px 0px 10px -25px;">
				<?php  
				$gravenofrom =55;
				$gravenoto = 56;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 2px 0px 0px 10px;">
				<?php  
				$gravenofrom =68;
				$gravenoto = 68;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 5px;">
				<?php  
				$gravenofrom =69;
				$gravenoto = 70;
				$height = 20;
				$width = 40; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row">
				<div style="margin: 2px 0px 0px  -25px; padding: 0px;" class="col-xs-3">
					<?php  
					$gravenofrom =87;
					$gravenoto = 87;
					$height = 60;
					$width = 20; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 2px 0px 0px 0px; padding: 0px;" class="col-xs-3">
					<?php  
					$gravenofrom =85;
					$gravenoto = 86;
					$height = 30;
					$width = 40; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 2px 0px 0px -3px; padding: 0px;" class="col-xs-2">
					<?php  
					$gravenofrom =84;
					$gravenoto = 84;
					$height = 60;
					$width = 40; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 2px 0px 0px -3px; padding: 0px;" class="col-xs-2">
					<?php  
					$gravenofrom =81;
					$gravenoto = 83;
					$height = 20;
					$width = 40; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
			</div>
			
		</td>  
	     <td>     
			<div style="margin: 0px 0px  0px -35px;">
				<?php  
				$gravenofrom =60;
				$gravenoto = 61;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>  
			<div style="margin: 0px 0px 0px -46px;">
				<?php  
				$gravenofrom =63;
				$gravenoto = 67;
				$height = 40;
				$width = 20; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div class="row">
				<div style="margin: 15px 0px 2px -20px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =71;
					$gravenoto = 72;
					$height = 15;
					$width = 40; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>  
				<div style="margin: 10px 0px 2px 0px;padding: 0px" class="col-xs-6">
					 <div style="margin: 0px 0px 0px 0px;padding: 0px">
						<?php  
						$gravenofrom =73;
						$gravenoto = 73;
						$height = 20;
						$width = 40; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
					</div> 
					<div style="margin: 0px 0px 0px 0px;padding: 0px">
						<?php  
						$gravenofrom =75;
						$gravenoto = 76;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
					</div> 
					<div style="margin: 0px 0px 0px 0px;padding: 0px">
						<?php  
						$gravenofrom =77;
						$gravenoto = 77;
						$height = 20;
						$width = 40; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
					</div> 
				</div> 
			</div> 
			<div class="row">
				<div style="margin: 20px 0px -40px -10px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =79;
					$gravenoto = 80;
					$height = 60;
					$width = 20; 
					retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>  
				<div style="margin: 20px 0px 2px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =77;
					$gravenoto = 78;
					$height = 40;
					$width = 25; 
					retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>    
			</div> 
			<div class="row">   
				<div style="margin: 0px 0px 15px 30px;padding: 0px" >
					<?php  
					$gravenofrom =105;
					$gravenoto = 105;
					$height = 20;
					$width = 40; 
					retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>    
			</div> 
			<div class="row">   
				<div style="margin: 0px 0px -80px -40px;padding: 0px" >
					<?php  
					$gravenofrom =88;
					$gravenoto = 93;
					$height = 40;
					$width = 20; 
					retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>    
			</div> 
		</td> 
		  <td>     
			<div class="row" style="margin: -100px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =62;
						$gravenoto = 62;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px -10px;padding: 0px 0px 0px 2px" class="col-xs-6">
					<?php  
						$gravenofrom =142;
						$gravenoto = 142;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div>
			<div class="row" style="margin: 0px 0px 20px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =137;
						$gravenoto = 138;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px  -10px;padding: 0px 0px 0px 0px" class="col-xs-3">
					<?php  
						$gravenofrom =139;
						$gravenoto = 139;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
				<div style="margin: 0px 0px 0px 0px;padding: 0px 0px 0px 0px" class="col-xs-3">
					<?php  
						$gravenofrom =140;
						$gravenoto = 141;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div>
			<div class="row" style="margin: 0px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =135;
						$gravenoto = 136;
						$height = 20;
						$width = 50; 
						retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =192;
						$gravenoto = 193;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>	
			<div class="row" style="margin: 0px 0px 30px 6px;">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =133;
						$gravenoto = 134;
						$height = 20;
						$width = 25; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: -15px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =131;
						$gravenoto = 132;
						$height = 20;
						$width = 25; 
						retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>	
			<div class="row" style="margin: 0px 0px 15px 6px;">
				<div style="margin: 0px 0px 0px 0px;padding: 0px">
					<?php  
						$gravenofrom =119;
						$gravenoto = 120;
						$height = 40;
						$width = 25; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>
			<div class="row" style="margin: 0px 0px 0px 15px;">
				<div style="margin: 0px 0px 0px 0px;padding: 0px">
					<?php  
						$gravenofrom =99;
						$gravenoto = 103;
						$height = 30;
						$width = 25; 
						retrieveData_ASC_Horizontal_C_odd($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>
			<div class="row" style="margin: 0px 0px 20px 15px;">
				<div style="margin: 0px 0px 0px 0px;padding: 0px">
					<?php  
						$gravenofrom =100;
						$gravenoto = 104;
						$height = 30;
						$width = 25; 
						retrieveData_ASC_Horizontal_C_even($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>	

			<div class="row" style="margin: 0px 0px -200px -5px;">
				<div style="margin: 0px 0px 0px 0px;padding: 0px">
					<?php  
						$gravenofrom =94;
						$gravenoto = 97;
						$height = 40;
						$width = 25; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
			</div>	 	  	 	   
		</td>                                                                         
		  <td>     
			<div class="row" style="margin: -50px 0px 0px 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =143;
						$gravenoto = 143;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px 0px 0px 2px" class="col-xs-6">
					<?php  
						$gravenofrom =144;
						$gravenoto = 144;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div> 	
			<div class="row" style="margin: 5px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =145;
						$gravenoto = 146;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div>
			<div class="row" style="margin: 5px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =194;
						$gravenoto = 195;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div> 
			<div class="row" style="margin: 5px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =127;
						$gravenoto = 127;
						$height = 60;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =130;
						$gravenoto = 130;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div>
			<div class="row" style="margin: 20px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =121;
						$gravenoto = 122;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
			</div> 	
			<div class="row" style="margin: 20px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =115;
						$gravenoto = 116;
						$height = 50;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
			</div> 
			<div class="row" style="margin: 20px 0px 0px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =108;
						$gravenoto = 108;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div> 	
			<div class="row" style="margin: 0px 0px -110px 6px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =106;
						$gravenoto = 107;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div>    	         	     
		</td> 
		 <td>     
			<div class="row" style="margin: 0px 0px 10px 0px">
				<div style="margin: 0px 0px 0px 30px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =147;
						$gravenoto = 147;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px -190px;padding: 0px 0px 0px 0px" class="col-xs-6">
					<?php  
						$gravenofrom =148;
						$gravenoto = 149;
						$height = 15;
						$width = 20; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div> 
			<div class="row" style="margin: 0px 0px 10px 30px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =150;
						$gravenoto = 151;
						$height = 30;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div>
			<div class="row" style="margin: 0px 0px 5px 30px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =189;
						$gravenoto = 189;
						$height = 30;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div> 
			<div class="row" style="margin: 0px 0px 5px 30px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =196;
						$gravenoto = 197;
						$height = 10;
						$width = 40; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div>  
			<div class="row" style="margin: 0px 0px 5px 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =128;
						$gravenoto = 129;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
				<div style="margin: 0px 0px 0px -160px;padding: 2px" class="col-xs-6">
					<?php  
						$gravenofrom =208;
						$gravenoto = 208;
						$height = 20;
						$width = 40; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px">
				<div style="margin: -7px 0px 0px 70px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =209;
						$gravenoto = 209;
						$height = 20;
						$width = 40; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div> 	 
			<div class="row" style="margin: 30px 0px 0px -30px">
				<div style="margin: 0px 0px 0px 70px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =123;
						$gravenoto = 126;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: -40px 0px 0px 150px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =210;
						$gravenoto = 211;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
				<div style="margin: -40px 0px 0px 200px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =213;
						$gravenoto = 214;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>     
			</div> 	
			<div class="row" style="margin: 0px 0px 10px 0px">
				<div style="margin: 0px 0px 0px 140px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =212;
						$gravenoto = 212;
						$height = 20;
						$width = 40; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px">
				<div style="margin: 0px 0px 0px 20px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =117;
						$gravenoto = 117;
						$height = 50;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: -50px 0px 0px 43px;padding: 0px" class="col-xs-10">
					<?php  
						$gravenofrom =224;
						$gravenoto = 230;
						$height = 50;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div> 	

			<div class="row" style="margin: 0px 0px 0px 0px">
				<div style="margin: 0px 0px 0px 20px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =110;
						$gravenoto = 110;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px 43px;padding: 0px" class="col-xs-10">
					<?php  
						$gravenofrom =111;
						$gravenoto = 114;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div> 	 	 		 	 	 	  	 	 	 	 		
		 	         	     
		</td>   
		 <td>     
			<div class="row" style="margin: -205px 0px 10px -310px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =153;
						$gravenoto = 154;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
			</div>  
			<div class="row" style="margin: 0px 0px 10px -350px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =152;
						$gravenoto = 152;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px 0px 0px  -90px;padding: 0px" class="col-xs-8">
					<?php  
						$gravenofrom =155;
						$gravenoto = 157;
						$height = 30;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
			</div>  
			 <div class="row" style="margin: 0px 0px 10px -360px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =190;
						$gravenoto = 191;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px 0px 0px  -140px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =199;
						$gravenoto = 200;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
			</div>  
		   <div class="row" style="margin: 0px 0px 30px -300px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-6">
					<?php  
						$gravenofrom =198;
						$gravenoto = 198;
						$height = 20;
						$width = 30; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				 
			</div> 
			<div class="row" style="margin: 0px 0px 10px -310px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-12">
					<?php  
						$gravenofrom =215;
						$gravenoto = 216;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>       
			</div>  
		</td>          
		 <td>     
			<div class="row" style="margin: 0px 0px 0px -250px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =158;
						$gravenoto = 158;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px 0px 0px -25px;padding: 0px" class="col-xs-10">
					<?php  
						$gravenofrom =161;
						$gravenoto = 187;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C_odd($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
			</div>   
			<div class="row" style="margin: 0px 0px 10px  -250px">
				<div style="margin: 0px 0px 0px  0px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =159;
						$gravenoto = 159;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px 0px 0px -25px;padding: 0px" class="col-xs-10">
					<?php  
						$gravenofrom =160;
						$gravenoto = 186;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C_even($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
			</div>   
			<div class="row" style="margin: 0px 0px 20px -250px">
				<div style="margin: 0px 0px 0px 30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =201;
						$gravenoto = 201;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px -30px 0px 0px;padding: 0px" class="col-xs-5">
					<?php  
						$gravenofrom =202;
						$gravenoto = 203;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>      
				<div style="margin: 0px 0px 0px -30px;padding: 0px" class="col-xs-5">
					<?php  
						$gravenofrom =301;
						$gravenoto = 303;
						$height = 30;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
			</div>
			<div class="row" style="margin: 0px 0px 10px -250px">
				<div style="margin: 0px 0px 0px 30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =204;
						$gravenoto = 205;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px -10px 20px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =206;
						$gravenoto = 207;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px -15px -5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =304;
						$gravenoto = 305;
						$height = 15;
						$width = 15; 
						retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
				<div style="margin: 0px 0px -20px -25px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =306;
						$gravenoto = 307;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
				<div style="margin: -18px 0px 0px -10px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =308;
						$gravenoto = 309;
						$height = 15;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
				<div style="margin: 0px 0px -25px -10px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =310;
						$gravenoto = 311;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    

			</div>
			<div class="row" style="margin: 0px 0px 0px -250px">
				<div style="margin: 0px 0px 0px 30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =217;
						$gravenoto = 217;
						$height = 15;
						$width = 30; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 10px 0px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =221;
						$gravenoto = 221;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>    
				<div style="margin: 0px 0px 10px -10px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =222;
						$gravenoto = 223;
						$height = 30;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: -40px 0px 10px 20px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =312;
						$gravenoto = 312;
						$height = 15;
						$width = 30; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: -20px 0px 10px 20px;padding: 0px" class="col-xs-2">

					<?php  
						$gravenofrom =313;
						$gravenoto = 314;
						$height = 15;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
					<?php  
						$gravenofrom =315;
						$gravenoto = 316;
						$height = 15;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>   
			</div>
			<div class="row" style="margin: 0px 0px 20px -250px">
				<div style="margin: 0px 0px 0px 30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =218;
						$gravenoto = 219;
						$height = 15;
						$width = 15; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px  30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =224;
						$gravenoto = 224;
						$height = 15;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div>  
				<div style="margin: 0px 0px 0px 15px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =296;
						$gravenoto = 296;
						$height = 15;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div> 
				<div style="margin: -15px 0px 0px -30px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =297;
						$gravenoto = 297;
						$height = 15;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div>  
				<div style="margin: -30px 0px 0px  5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =298;
						$gravenoto = 300;
						$height = 15;
						$width = 30; 
						retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div>  
			</div>
			
			<div class="row" style="margin: 0px 0px 20px 0px">
				<div style="margin: 0px 0px 0px -200px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =220;
						$gravenoto = 220;
						$height = 50;
						$width = 30; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px -120px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =294;
						$gravenoto = 295;
						$height = 20;
						$width = 15; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
					<?php  
						$gravenofrom =292;
						$gravenoto = 293;
						$height = 30;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px -20px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =291;
						$gravenoto = 291;
						$height = 50;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div> 
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =295;
						$gravenoto = 295;
						$height = 50;
						$width = 30; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?> 
				</div>  
			</div>
			<div class="row" style="margin: 0px 0px 20px -250px">
				<div style="margin: 0px 0px 5px 0px;padding: 0px" class="col-xs-1">
					<?php  
						$gravenofrom =231;
						$gravenoto = 231;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				 <div style="margin: 0px 0px 0px 5px;padding: 0px" class="col-xs-1">
					<?php  
						$gravenofrom =230;
						$gravenoto = 230;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px  5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =233;
						$gravenoto = 234;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px  5px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =278;
						$gravenoto = 280;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px 5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =281;
						$gravenoto = 281;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin:0px 0px 0px -25px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =282;
						$gravenoto = 283;
						$height = 20;
						$width = 20; 
						retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
		   
			</div>
			<div class="row" style="margin: 0px 0px 10px -270px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-1">
					<?php  
						$gravenofrom =241;
						$gravenoto = 241;
						$height = 40;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-4">
					<?php  
						$gravenofrom =237;
						$gravenoto = 240;
						$height = 40;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px 20px;padding: 0px" class="col-xs-1">
					<?php  
						$gravenofrom =236;
						$gravenoto = 236;
						$height = 40;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: -20px 0px 0px -80px;padding: 0px" class="col-xs-1">
					<?php  
						$gravenofrom =235;
						$gravenoto = 235;
						$height = 20;
						$width = 40; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
				<div style="margin: 0px 0px 0px 5px;padding: 0px" class="col-xs-2">
					<?php  
						$gravenofrom =277;
						$gravenoto = 278;
						$height = 20;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
					<?php  
						$gravenofrom =263;
						$gravenoto = 264;
						$height = 40;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div> 
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-3">
					<?php  
						$gravenofrom =275;
						$gravenoto = 275;
						$height = 20;
						$width = 40; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
					<?php  
						$gravenofrom =265;
						$gravenoto = 265;
						$height = 30;
						$width = 20; 
						retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
					<?php  
						$gravenofrom =261;
						$gravenoto = 262;
						$height = 20;
						$width = 20; 
						retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); 
					?>
				</div>  
			</div>
		</td>            
	</tr>
	<tr>
		<td height="60"></td>
	</tr>
</table>

 