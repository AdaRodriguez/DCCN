<table style="margin-left: 100px"> 
	<tr>
		<td> 
			<div style="margin: 0px 0px 0px -35px;">
				<?php  
				$gravenofrom =685;
				$gravenoto = 685;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px -35px;">
				<?php  
				$gravenofrom =680;
				$gravenoto = 681;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px -35px;">
				<?php  
				$gravenofrom =647;
				$gravenoto = 648;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px -30px;">
				<?php  
				$gravenofrom =642;
				$gravenoto = 646;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px -25px;">
				<?php  
				$gravenofrom =637;
				$gravenoto = 641;
				$height = 20;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px -10px;">
				<?php  
				$gravenofrom =627;
				$gravenoto = 636;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>

			<div style="margin: 0px 0px 0px -5px;">
				<?php  
				$gravenofrom =621;
				$gravenoto = 626;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px -5px;">
				<?php  
				$gravenofrom =539;
				$gravenoto = 543;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px -15px -30px;">
				<?php  
				$gravenofrom =538;
				$gravenoto = 538;
				$height = 30;
				$width = 15; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px -5px;">
				<?php  
				$gravenofrom =536;
				$gravenoto = 537;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>

			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =530;
				$gravenoto = 530;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =528;
				$gravenoto = 529;
				$height = 15;
				$width = 15; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =526;
				$gravenoto = 527;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =525;
				$gravenoto = 525;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>  
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =523;
				$gravenoto = 524;
				$height = 15;
				$width = 15; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>    
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =521;
				$gravenoto = 522;
				$height = 30;
				$width = 15; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>    
		</td> 
		<td> 
			<div style="margin: 0px 0px 10px -10px;">
				<?php  
				$gravenofrom =687;
				$gravenoto =688;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px -10px;">
				<?php  
				$gravenofrom =686;
				$gravenoto =686;
				$height = 30;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px -10px;">
				<?php  
				$gravenofrom =681;
				$gravenoto =683;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px -10px;">
				<?php  
				$gravenofrom =679;
				$gravenoto = 679;
				$height = 30;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px -10px;">
				<?php  
				$gravenofrom =677;
				$gravenoto = 678;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>

			<div style="margin: 0px 0px 0px -5px;">
				<?php  
				$gravenofrom =676;
				$gravenoto = 676;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 0px -5px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =673;
					$gravenoto = 674;
					$height = 15;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =675;
					$gravenoto = 675;
					$height = 30;
					$width = 15; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div class="row" style="margin: 0px 0px 5px -5px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =667;
					$gravenoto = 669;
					$height = 15;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =670;
					$gravenoto = 672;
					$height = 15;
					$width = 15; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div style="margin: 0px 0px 0px -5px;">
				<?php  
				$gravenofrom =659;
				$gravenoto = 666;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 5px -5px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =655;
					$gravenoto = 656;
					$height = 20;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =658;
					$gravenoto = 658;
					$height = 30;
					$width = 20; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =651;
					$gravenoto = 654;
					$height = 20;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =657;
					$gravenoto = 657;
					$height = 30;
					$width = 20; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =620;
				$gravenoto = 620;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =562;
				$gravenoto = 562;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =560;
				$gravenoto = 561;
				$height = 15;
				$width = 15; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =558;
				$gravenoto = 559;
				$height = 15;
				$width = 15; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =557;
				$gravenoto = 557;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =555;
				$gravenoto = 556;
				$height = 15;
				$width = 15; 
				retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =554;
				$gravenoto = 554;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =552;
				$gravenoto = 553;
				$height = 15;
				$width = 15; 
				retrieveData_ASC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =550;
				$gravenoto = 551;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =546;
				$gravenoto = 549;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 5px 0px;">
				<?php  
				$gravenofrom =545;
				$gravenoto = 545;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 30px 0px;">
				<?php  
				$gravenofrom =544;
				$gravenoto = 544;
				$height = 15;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
		</td> 
		<td>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =691;
				$gravenoto =693;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =680;
				$gravenoto =680;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 20px 0px;">
				<?php  
				$gravenofrom =689;
				$gravenoto =689;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =709;
				$gravenoto =709;
				$height = 15;
				$width = 15; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 20px 0px;">
				<?php  
				$gravenofrom =710;
				$gravenoto =714;
				$height = 10;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =722;
				$gravenoto =736;
				$height = 10;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =750;
				$gravenoto =750;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =751;
				$gravenoto =765;
				$height = 10;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 5px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =787;
					$gravenoto = 787;
					$height = 30;
					$width = 20; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =781;
					$gravenoto = 782;
					$height = 15;
					$width = 20; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =784;
				$gravenoto =785;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =786;
				$gravenoto =786;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =789;
				$gravenoto =789;
				$height = 30;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =790;
				$gravenoto =802;
				$height = 10;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
		</td> 
		<td>
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =694;
				$gravenoto =702;
				$height = 10;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =703;
				$gravenoto =708;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =715;
				$gravenoto =719;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =720;
				$gravenoto =721;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =725;
				$gravenoto =726;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =731;
				$gravenoto =732;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =738;
				$gravenoto =741;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =742;
				$gravenoto =749;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 10px 0px;">
				<?php  
				$gravenofrom =766;
				$gravenoto =772;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =773;
				$gravenoto =781;
				$height = 15;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =788;
				$gravenoto =788;
				$height = 30;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =805;
				$gravenoto =810;
				$height = 20;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 0px;">
				<?php  
				$gravenofrom =808;
				$gravenoto =808;
				$height = 30;
				$width = 30; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div> 
		</td>
		<td>
			<div style="margin: 0px 0px 5px 10px;">
				<?php  
				$gravenofrom =980;
				$gravenoto =980;
				$height = 40;
				$width = 60; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div>
			<div style="margin: 0px 0px 10px 10px;">
				<?php  
				$gravenofrom =977;
				$gravenoto =979;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 15px 15px;">
				<?php  
				$gravenofrom =974;
				$gravenoto =976;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =969;
				$gravenoto =972;
				$height = 24;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =963;
				$gravenoto =968;
				$height = 15;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 25px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =959;
					$gravenoto =959;
					$height = 40;
					$width = 30; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =960;
					$gravenoto =960;
					$height = 40;
					$width = 10; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
			</div>
			 <div class="row" style="margin: 0px 0px 15px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =962;
					$gravenoto =962;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =955;
					$gravenoto =957;
					$height = 15;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =958;
					$gravenoto =958;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div class="row" style="margin: 0px 0px 0px 20px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =949;
					$gravenoto =951;
					$height = 10;
					$width = 40; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px -5px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =952;
					$gravenoto =953;
					$height = 30;
					$width = 10; 
					retrieveData_DESC_Horizontal_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
			</div>
			 <div class="row" style="margin: 0px 0px 0px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =947;
					$gravenoto =947;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =944;
					$gravenoto =945;
					$height = 15;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =948;
					$gravenoto =948;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
		<div style="margin: 0px 0px 0px 15px;">
			<?php  
			$gravenofrom =943;
			$gravenoto =943;
			$height = 15;
			$width = 40; 
			retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
		</div> 
		 <div class="row" style="margin: 0px 0px 0px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =940;
					$gravenoto =940;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-6">
					<?php  
					$gravenofrom =941;
					$gravenoto =942;
					$height = 15;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-3">
					<?php  
					$gravenofrom =946;
					$gravenoto =946;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =878;
				$gravenoto =878;
				$height = 10;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =879;
					$gravenoto =879;
					$height = 30;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =876;
					$gravenoto =877;
					$height = 15;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =875;
				$gravenoto =875;
				$height = 10;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding: 0px">
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-4">
					<?php  
					$gravenofrom =875;
					$gravenoto =875;
					$height = 40;
					$width = 10; 
					retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div> 
				<div style="margin: 0px 0px 0px 0px;padding: 0px" class="col-xs-8">
					<?php  
					$gravenofrom =872;
					$gravenoto =874;
					$height = 10;
					$width = 30; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =863;
				$gravenoto =871;
				$height = 10;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =833;
				$gravenoto =845;
				$height = 10;
				$width = 30; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
			<div style="margin: 0px 0px 0px 15px;">
				<?php  
				$gravenofrom =811;
				$gravenoto =811;
				$height = 30;
				$width = 30; 
				retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div> 
		</td>
		<td>
			<div style="margin: 0px 0px 10px 0px;padding:0px">
					<?php  
					$gravenofrom =981;
					$gravenoto =981;
					$height = 40;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div style="margin: 0px 0px 10px 0px;padding:0px">
					<?php  
					$gravenofrom =982;
					$gravenoto =982;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 25px 0px;padding:0px">
					<?php  
					$gravenofrom =973;
					$gravenoto =973;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 50px 0px;padding:0px">
					<?php  
					$gravenofrom =970;
					$gravenoto =970;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div class="row" style="margin: 0px 0px 5px 0px;padding:0px ">
				<div style="margin: 0px 0px 0px 0px;padding:0px " class="col-xs-8">
					<?php  
					$gravenofrom =932;
					$gravenoto =932;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -2px;padding:0px " class="col-xs-4">
					<?php  
					$gravenofrom =939;
					$gravenoto =939;
					$height = 40;
					$width = 10; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px ">
				<div style="margin: 0px 0px 0px 0px;padding:0px " class="col-xs-8">
					<?php  
					$gravenofrom =934;
					$gravenoto =936;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -2px;padding:0px " class="col-xs-4">
					<?php  
					$gravenofrom =938;
					$gravenoto =938;
					$height = 40;
					$width = 10; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div style="margin: 0px 0px 0px 0px;padding:0px">
					<?php  
					$gravenofrom =933;
					$gravenoto =933;
					$height = 40;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =932;
					$gravenoto =932;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =931;
					$gravenoto =931;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 0px 0px;padding:0px">
					<?php  
					$gravenofrom =930;
					$gravenoto =930;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =890;
					$gravenoto =890;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px ">
				<div style="margin: 0px 0px 0px 0px;padding:0px " class="col-xs-8">
					<?php  
					$gravenofrom =881;
					$gravenoto =889;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div style="margin: 0px 0px 0px -2px;padding:0px " class="col-xs-4">
					<?php  
					$gravenofrom =891;
					$gravenoto =892;
					$height = 40;
					$width = 10; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			 <div style="margin: 0px 0px 5px 0px;padding:0px ">
				<?php  
				$gravenofrom =880;
				$gravenoto =880;
				$height = 40;
				$width = 40; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div>
			 <div style="margin: 0px 0px 0px 15px;padding:0px ">
				<?php  
				$gravenofrom =846;
				$gravenoto =851;
				$height = 10;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			 <div style="margin: 0px 0px 0px 15px;padding:0px ">
				<?php  
				$gravenofrom =843;
				$gravenoto =843;
				$height = 30;
				$width = 40; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div>
			 <div style="margin: 0px 0px 0px 15px;padding:0px ">
				<?php  
				$gravenofrom =829;
				$gravenoto =831;
				$height = 10;
				$width = 40; 
				retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			</div>
			 <div style="margin: 0px 0px 5px 15px;padding:0px ">
				<?php  
				$gravenofrom =820;
				$gravenoto =820;
				$height = 30;
				$width = 40; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div>
		     <div style="margin: 0px 0px 0px 15px;padding:0px ">
				<?php  
				$gravenofrom =812;
				$gravenoto =812;
				$height = 40;
				$width = 40; 
				retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			</div>
		</td>
		<td>
			<div style="margin: 0px 0px 10px 0px;padding:0px">
					<?php  
					$gravenofrom =983;
					$gravenoto =983;
					$height = 60;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div style="margin: 0px 0px 0px 0px;padding:0px">
					<?php  
					$gravenofrom =984;
					$gravenoto =986;
					$height = 40;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div style="margin: 0px 0px 10px 0px;padding:0px">
					<?php  
					$gravenofrom =987;
					$gravenoto =987;
					$height = 40;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div style="margin: 0px 0px 0px 0px;padding:0px">
					<?php  
					$gravenofrom =988;
					$gravenoto =988;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =925;
					$gravenoto =925;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =923;
					$gravenoto =924;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =918;
					$gravenoto =919;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div style="margin: 0px 0px 5px 0px;padding:0px">
					<?php  
					$gravenofrom =910;
					$gravenoto =916;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>

			<div style="margin: 0px 0px 0px 30px;padding:0px">
					<?php  
					$gravenofrom =905;
					$gravenoto =908;
					$height = 20;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>

			 <div style="margin: 0px 0px 0px 30px;padding:0px">
					<?php  
					$gravenofrom =903;
					$gravenoto =903;
					$height = 40;
					$width = 40; 
					retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
			 </div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
						<?php $gravenofrom =902;
							$gravenoto =902;
							$height = 20;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
					<?php $gravenofrom =898;
							$gravenoto =898;
							$height = 20;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
				</div>
				<div  style="margin: 0px 0px 0px -3px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =899;
							$gravenoto =900;
							$height = 10;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
						<?php $gravenofrom =896;
							$gravenoto =896;
							$height = 10;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
					 
				</div>
			</div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =893;
							$gravenoto =895;
							$height = 10;
							$width = 40; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
				</div>
				<div  style="margin: 0px 0px 0px -3px;padding:0px" class="col-xs-6" >
						<?php $gravenofrom =897;
							$gravenoto =897;
							$height = 20;
							$width = 10; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
					<?php $gravenofrom =860;
							$gravenoto =860;
							$height = 20;
							$width = 10; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			 <div style="margin: 0px 0px 0px 30px;padding:0px">
					<?php  
					$gravenofrom =857;
					$gravenoto =859;
					$height = 10;
					$width = 40; 
					retrieveData_DESC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
			 </div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =853;
							$gravenoto =853;
							$height = 30;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
				</div>
				<div  style="margin: 0px 0px 0px -3px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =855;
							$gravenoto =856;
							$height = 20;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =852;
							$gravenoto =852;
							$height = 30;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
				</div>
				<div  style="margin: 0px 0px 0px -3px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =854;
							$gravenoto =854;
							$height = 20;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =826;
							$gravenoto =826;
							$height = 30;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?> 
				</div>
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =827;
							$gravenoto =828;
							$height = 10;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div>
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =825;
							$gravenoto =825;
							$height = 10;
							$width = 30; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
					<?php $gravenofrom =821;
							$gravenoto =821;
							$height = 30;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =822;
							$gravenoto =824;
							$height = 10;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =890;
							$gravenoto =890;
							$height = 10;
							$width = 30; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
					<?php $gravenofrom =818;
							$gravenoto =818;
							$height = 10;
							$width = 30; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =815;
							$gravenoto =817;
							$height = 10;
							$width = 40; 
							retrieveData_desc_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
			</div> 
			<div class="row" style="margin: 0px 0px 0px 0px;padding:0px">
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =813;
							$gravenoto =813;
							$height = 20;
							$width = 10; 
							retrieveData_ASC_Vertical_C($gravenofrom,$gravenoto,$height,$width); ?>
				</div>
				<div  style="margin: 0px 0px 0px 0px;padding:0px" class="col-xs-6" >
					<?php $gravenofrom =814;
							$gravenoto =814;
							$height = 40;
							$width = 40; 
							retrieveData_ASC_Vertical_C_bgcolor($gravenofrom,$gravenoto,$height,$width,'bgcolor_C'); ?>
				</div>
			</div> 
		</td>
	</tr>
</table>