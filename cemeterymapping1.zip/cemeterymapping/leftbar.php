
 <div class="row" style="font-size: 12px">
  <div class="col-md-12">
        <div class="panel panel-default" > 
    <div class="panel-body">
    <div class="list-group">
     <div class="well well-sm "><b>   Office hours of St. John the Baptist </b> </div>
        <ul >
            <li>  
              <b>Monday - Friday 8:00AM - 5:00PM </b> 
            </li>
          
         </ul> 
         
      </div> 
   </div> 
</div>

  </div>
 </div>
 