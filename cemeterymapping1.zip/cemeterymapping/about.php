
<style type="text/css">
    .row div {
        font-size: 13px;
        font-weight: bold;
        border-bottom: .5px solid #ddd;
        margin-bottom: 1px;
    }
</style>
<div class="row"> 
    <div class="col-lg-12">
        <div><img src="img/miserav.jpg" title="img" style="width: 100px;height: 100px"> MISERAV</div>
   
    </div>
        
</div>