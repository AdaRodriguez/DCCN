<?php
// Define directory separator constant if not defined
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);

// Define library path constant
defined('LIB_PATH') ? null : define('LIB_PATH', __DIR__ . DS . 'include');

require_once(__DIR__ . DIRECTORY_SEPARATOR . 'database.php');


class User {
    protected static $tblname = "tbluseraccount";

    function dbfields() {
        global $mydb;
        return $mydb->getFieldsOnOneTable(self::$tblname);
    }

    function listofuser() {
        global $mydb;
        $mydb->setQuery("SELECT * FROM " . self::$tblname);
        return $mydb->executeQuery();
    }

    function find_user($id = "", $user_name = "") {
        global $mydb;
        $mydb->setQuery("SELECT * FROM " . self::$tblname . " WHERE USERID = {$id} OR U_USERNAME = '{$user_name}'");
        $cur = $mydb->executeQuery();
        $row_count = $mydb->num_rows($cur);
        return $row_count;
    }

    static function userAuthentication($U_USERNAME, $h_pass) {
        global $mydb;
        $mydb->setQuery("SELECT * FROM `tbluseraccount` WHERE `U_USERNAME` = '" . $U_USERNAME . "' and `U_PASS` = '" . $h_pass . "'");
        $cur = $mydb->executeQuery();
        if ($cur == false) {
            die(mysqli_error($mydb->conn));
        }
        $row_count = $mydb->num_rows($cur);
        if ($row_count == 1) {
            $user_found = $mydb->loadSingleResult();
            $_SESSION['USERID'] = $user_found->USERID;
            $_SESSION['U_NAME'] = $user_found->U_NAME;
            $_SESSION['U_USERNAME'] = $user_found->U_USERNAME;
            $_SESSION['U_PASS'] = $user_found->U_PASS;
            $_SESSION['U_ROLE'] = $user_found->U_ROLE;
            return true;
        } else {
            return false;
        }
    }

    function single_user($id = "") {
        global $mydb;
        $mydb->setQuery("SELECT * FROM " . self::$tblname . " Where USERID= '{$id}' LIMIT 1");
        return $mydb->loadSingleResult();
    }

    static function instantiate($record) {
        $object = new self;
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    private function has_attribute($attribute) {
        return array_key_exists($attribute, $this->attributes());
    }

    protected function attributes() {
        global $mydb;
        $attributes = array();
        foreach ($this->dbfields() as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    protected function sanitized_attributes() {
        global $mydb;
        $clean_attributes = array();
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $mydb->escape_value($value);
        }
        return $clean_attributes;
    }

    public function save() {
        return isset($this->id) ? $this->update() : $this->create();
    }

    public function create() {
        global $mydb;
        $attributes = $this->sanitized_attributes();
        $sql = "INSERT INTO " . self::$tblname . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        $mydb->setQuery($sql);
        if ($mydb->executeQuery()) {
            $this->id = $mydb->insert_id();
            return true;
        } else {
            return false;
        }
    }

    public function update($id = 0) {
        global $mydb;
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . self::$tblname . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE USERID=" . $id;
        $mydb->setQuery($sql);
        return $mydb->executeQuery();
    }

    public function delete($id = 0) {
        global $mydb;
        $sql = "DELETE FROM " . self::$tblname;
        $sql .= " WHERE USERID=" . $id;
        $sql .= " LIMIT 1 ";
        $mydb->setQuery($sql);
        return $mydb->executeQuery();
    }
}
?>
